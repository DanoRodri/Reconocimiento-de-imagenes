var Camara;
var BotonesEntrenar
var knn;
var modelo;
var Texto;
var Clasificando = false;
var InputTextbox;
var BotonTextBox;


//
var voices;
//Inicializamos utter.
var utter = new SpeechSynthesisUtterance();
utter.rate = 1;
utter.pitch = 0.5;
utter.lang = 'es-AR';
//Cargamos las voces que tenemos en nuestro sistema y las mostarmos en un arreglo por consola.
window.speechSynthesis.onvoiceschanged = function () {
    voices = window.speechSynthesis.getVoices();
    console.log(voices);
};


function setup() {
createCanvas(320,240);
background(255,0,0);
Camara = createCapture(VIDEO);
Camara.size(320,340);
Camara.hide();

modelo = ml5.featureExtractor('MobileNet', ModeloListo);
knn = ml5.KNNClassifier();


createP('presiona los botones para entrenar');

var BotonEncendedor = createButton("Encendedor");
BotonEncendedor.class("BotonEntrenar");

var BotonCelular = createButton("Celular");
BotonCelular.class("BotonEntrenar");

var BotonCartera = createButton("Cartera");
BotonCartera.class("BotonEntrenar");

var BotonPapel = createButton("Papel");
BotonPapel.class("BotonEntrenar");

var BotonNada = createButton("Nada");
BotonNada.class("BotonEntrenar");

var BotonVoz = createButton("Voz");
BotonVoz.class("BotonVoz");
BotonVoz.mousePressed(Hablar);

var BotonTex = createButton("Texto");
BotonTex.class("BotonTexto");
BotonTex.mousePressed(Tex);

createP("entrena usando textBox");


InputTextbox = createInput("cosa 2");
Texto = createP("Modelo no listo, esperando");
BotonTextBox = createButton("Entrenando con "+InputTextbox.value());
BotonTextBox.mousePressed(EntrenarTextBox);

createP("Guarda o Carga tu Neurona");
var BotonGuardar = createButton("Guardar");
 BotonGuardar.mousePressed(GuardadNeurona);
 var BotonCargar = createButton("Cargar");
 BotonCargar.mousePressed(CargarNeurona);



BotonesEntrenar = selectAll(".BotonEntrenar");



for (var B = 0; B < BotonesEntrenar.length; B++) {
    BotonesEntrenar[B].style("margin", "5px");
    BotonesEntrenar[B].style("padding", "6px");
    BotonesEntrenar[B].mousePressed(PresionandoBoton);

}

}
function Tex(){
  // Create the character level generator with a pre trained model
// When the model is loaded
function modelLoaded() {
  console.log('Model Loaded!');
}

// Generate content
rnn.generate({ seed: 'the meaning of pizza is' }, (err, results) => {
  console.log(results);
});
}

function Hablar(cosa) {
    utter.text = cosa;
    //Setea la voz que queremos usar en base a nuestra lista.
    utter.voice = voices[1];
    window.speechSynthesis.speak(utter);
}

function PresionandoBoton(){
  var NombreBoton = this.elt.innerHTML;
    console.log("Entrenando con " + NombreBoton);
    EntrenarKnn(NombreBoton);
}

function EntrenarKnn(ObjetoEntrenar){
const Imagen = modelo.infer(Camara);
knn.addExample(Imagen, ObjetoEntrenar);
}

function ModeloListo(){
  console.log("modelo listo");
  Texto.html("Modelo listo, Empieza a entrenar");
}

function clasificar(){
  var regreso;
  const Imagen = modelo.infer(Camara);
  knn.classify(Imagen, function(error, result) {
    if (error) {
      console.error();
    } else {
      Texto.html("Es un " + result.label);
      //clasificar();
      regreso = result.label;

      Hablar(result.label);

    }

  })
}
function EntrenarTextBox(){
  const Imagen = modelo.infer(Camara);
  knn.addExample(Imagen, InputTextbox.value());
}

function GuardadNeurona() {
  if (Clasificando) {
    save(knn, "Neurona1.json");
  }
}
function CargarNeurona() {
  console.log("Cargando una Neurona");
  knn.load("./Neuronas/Neurona1.json", function() {
    console.log("Neurona Cargada knn");
    Texto.html("Neurona cargana de archivo");
  })
}

function draw() {
  image(Camara,0,0,320,240);
  BotonTextBox.html("Entrenar con "+InputTextbox.value());
  if (knn.getNumLabels()>0 && !Clasificando) {
    //clasificar();
    setInterval(clasificar, 500);
    Clasificando = true;
  }
}


// Temporary save code until ml5 version 0.2.2
const save = (knn, name) => {
  const dataset = knn.knnClassifier.getClassifierDataset();
  if (knn.mapStringToIndex.length > 0) {
    Object.keys(dataset).forEach(key => {
      if (knn.mapStringToIndex[key]) {
        dataset[key].label = knn.mapStringToIndex[key];
      }
    });
  }
  const tensors = Object.keys(dataset).map(key => {
    const t = dataset[key];
    if (t) {
      return t.dataSync();
    }
    return null;
  });
  let fileName = 'myKNN.json';
  if (name) {
    fileName = name.endsWith('.json') ? name : `${name}.json`;
  }
  saveFile(fileName, JSON.stringify({
    dataset,
    tensors
  }));
};

const saveFile = (name, data) => {
  const downloadElt = document.createElement('a');
  const blob = new Blob([data], {
    type: 'octet/stream'
  });
  const url = URL.createObjectURL(blob);
  downloadElt.setAttribute('href', url);
  downloadElt.setAttribute('download', name);
  downloadElt.style.display = 'none';
  document.body.appendChild(downloadElt);
  downloadElt.click();
  document.body.removeChild(downloadElt);
  URL.revokeObjectURL(url);
};
